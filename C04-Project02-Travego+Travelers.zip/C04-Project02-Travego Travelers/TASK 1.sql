#TASK 1
#1. (Easy) Creating the schema and required tables using MySQL workbench
#a. Create a schema named Travego and create the tables mentioned above with the mentioned column names. Also, declare the relevant datatypes for each feature/column in the dataset.
CREATE DATABASE TRAVEGO;
USE TRAVEGO;

CREATE TABLE Passenger(
Passenger_id INT,
Passenger_name VARCHAR(20),
Category VARCHAR(20),
Gender VARCHAR(20),
Boarding_City VARCHAR(20),
Destination_City VARCHAR(20),
Distance INT,
Bus_Type VARCHAR(20));

CREATE TABLE Price(
id INT,
Bus_Type VARCHAR(20),
Distance INT,
Price INT);

#b. Insert the data in the newly created tables.
INSERT INTO PASSENGER VALUES(1,'Sejal','AC','F','Bengaluru','Chennai',350,'Sleeper');
INSERT INTO PASSENGER VALUES(2,'Anmol','NON-AC','M','Mumbai','Hyderabad',700,'Sitting');
INSERT INTO PASSENGER VALUES(3,'Pallavi','AC','F','Panaji','Bengaluru',600,'Sleeper');
INSERT INTO PASSENGER VALUES(4,'Khusboo','AC','F','Chennai','Mumbai',1500,'Sleeper');
INSERT INTO PASSENGER VALUES(5,'Udit','NON-AC','M','Trivandrum','Panaji',1000,'Sleeper');
INSERT INTO PASSENGER VALUES(6,'Ankur','AC','F','Nagpur','Hyderabad',500,'Sitting');
INSERT INTO PASSENGER VALUES(7,'Hemant','NON-AC','M','Panaji','Mumbai',700,'Sleeper');
INSERT INTO PASSENGER VALUES(8,'Manish','NON-AC','M','Hyderabad','Bengaluru',500,'Sitting');
INSERT INTO PASSENGER VALUES(9,'Piyush','AC','M','Pune','Nagpur',700,'Sitting');

INSERT INTO PRICE VALUES(1,'SLEEPER',350,770);
INSERT INTO PRICE VALUES(2,'SLEEPER',500,1100);
INSERT INTO PRICE VALUES(3,'SLEEPER',600,1320);
INSERT INTO PRICE VALUES(4,'SLEEPER',700,1540);
INSERT INTO PRICE VALUES(5,'SLEEPER',1000,2200);
INSERT INTO PRICE VALUES(6,'SLEEPER',1200,2640);
INSERT INTO PRICE VALUES(7,'SLEEPER',1500,2700);
INSERT INTO PRICE VALUES(8,'SITTING',500,620);
INSERT INTO PRICE VALUES(9,'SITTING',600,744);
INSERT INTO PRICE VALUES(10,'SITTING',700,868);
INSERT INTO PRICE VALUES(11,'SITTING',1000,1240);
INSERT INTO PRICE VALUES(12,'SITTING',1200,1488);
INSERT INTO PRICE VALUES(13,'SITTING',1500,1860);

SELECT * FROM PASSENGER;
SELECT * FROM PRICE;
