#TASK 2
USE TRAVEGO;
#2.(Medium) Perform read operation on the designed table created in the above task
#QUESTION(A):How many female passengers traveled a minimum distance of 600 KMs?
SELECT COUNT(*) 
FROM Passenger
WHERE Gender = 'F' AND Distance >= 600;

#QUESTION(B):Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus?
SELECT * FROM Passenger
WHERE Distance > 500 AND Bus_Type = 'Sleeper';

#QUESTION(C):Select passenger names whose names start with the character 'S'?
SELECT Passenger_name
FROM Passenger
WHERE Passenger_name LIKE 'S%';

#QUESTION(D):Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,Destination City, Bus type, and Price in the output?
SELECT 
    p.Passenger_name,
    p.Boarding_City, 
    p.Destination_City,
    p.Bus_Type,
    pr.Price
FROM Passenger p
JOIN Price pr ON p.Bus_Type = pr.Bus_Type AND p.Distance = pr.Distance;

#QUESTION(E):What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?
SELECT 
    p.Passenger_name, pr.Price
FROM Passenger p
JOIN Price pr ON p.Bus_Type = pr.Bus_Type AND p.Distance = pr.Distance  
WHERE p.Bus_Type = 'Sitting' AND p.Distance = 1000;

#QUESTION(F):What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?
select passenger_name,pr.bus_type,pr.price
from passenger p left join price pr on p.distance = pr.distance
where p.passenger_name = 'Pallavi';

#QUESTION(G):Alter the column category with the value "Non-AC" where the Bus_Type is sleeper?
UPDATE Passenger
SET Category = 'Non-AC'
WHERE Bus_Type = 'Sleeper';

#QUESTION(H):Delete an entry from the table where the passenger name is Piyush and commit this change in the database.?
DELETE FROM Passenger 
WHERE Passenger_name = 'Piyush';
COMMIT;

#QUESTION(I):Truncate the table passenger and comment on the number of rows in the table (explain if required)?
TRUNCATE TABLE Passenger;
SELECT COUNT(*) FROM Passenger;

#QUESTION(J):Delete the table passenger from the database?
DROP TABLE Passenger;


select * from passenger;
SELECT * FROM PRICE;
show tables;
SHOW DATABASES;