USE film_rental;
SHOW TABLES;

SELECT * FROM ACTOR;
SELECT * FROM ADDRESS;
SELECT * FROM CATEGORY;
SELECT * FROM CITY;
SELECT * FROM COUNTRY;
SELECT * FROM CUSTOMER;
SELECT * FROM FILM;
SELECT * FROM FILM_ACTOR;
SELECT * FROM FILM_CATEGORY;
SELECT * FROM INVENTORY;
SELECT  * FROM LANGUAGE;
SELECT * FROM PAYMENT;
SELECT * FROM RENTAL;
SELECT * FROM STAFF;
SELECT * FROM STORE;
----------------------------------------------------------------------------------------------------------------------------------
#QUESTION-1:What is the total revenue generated from all rentals in the database?
SELECT SUM(amount) AS total_revenue
FROM payment;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-2:How many rentals were made in each month_name?
SELECT MONTHNAME(rental_date) AS month, COUNT(*) AS rental_count
FROM rental
GROUP BY MONTHNAME(rental_date);
----------------------------------------------------------------------------------------------------------------------
#QUESTION-3:What is the rental rate of the film with the longest title in the database? 
SELECT rental_rate,title
FROM film
WHERE length(title) = (SELECT MAX(length(title)) FROM film);
----------------------------------------------------------------------------------------------------------------------
#QUESTION-4:What is the average rental rate for films that were taken from the last 30 days from the date("2005-05-05 22:04:30")?
SELECT AVG(f.rental_rate) AS average_rental_rate
FROM rental r
JOIN film f ON r.inventory_id = f.film_id
WHERE r.rental_date >= DATE_SUB('2005-05-05 22:04:30', INTERVAL 30 DAY);
----------------------------------------------------------------------------------------------------------------------
#QUESTION-5:What is the most popular category of films in terms of the number of rentals?
SELECT c.name AS category, COUNT(r.rental_id) AS rental_count
FROM film_category fc
JOIN rental r ON fc.film_id = r.inventory_id
JOIN category c ON fc.category_id = c.category_id
GROUP BY fc.category_id
ORDER BY rental_count DESC
LIMIT 1;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-6:Find the longest movie duration from the list of films that have not been rented by any customer.?
SELECT MAX(f.length) AS longest_movie_duration
FROM film f
LEFT JOIN inventory i ON f.film_id = i.film_id
LEFT JOIN rental r ON i.inventory_id = r.inventory_id
WHERE r.rental_id IS NULL;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-7:What is the average rental rate for films, broken down by category?
SELECT
    c.name AS category,
    AVG(f.rental_rate) AS average_rental_rate
FROM
    film f
JOIN
    film_category fc ON f.film_id = fc.film_id
JOIN
    category c ON fc.category_id = c.category_id
GROUP BY
    c.name;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-8:What is the total revenue generated from rentals for each actor in the database?
SELECT
  A.ACTOR_ID,
  CONCAT(A.FIRST_NAME, ' ', A.LAST_NAME) AS ACTOR_NAME,
  SUM(P.AMOUNT) AS TOTAL_REVENUE
FROM
  ACTOR A
  JOIN FILM_ACTOR FA ON A.ACTOR_ID = FA.ACTOR_ID
  JOIN FILM F ON FA.FILM_ID = F.FILM_ID
  JOIN INVENTORY I ON F.FILM_ID = I.FILM_ID
  JOIN RENTAL R ON I.INVENTORY_ID = R.INVENTORY_ID
  JOIN PAYMENT P ON R.RENTAL_ID = P.RENTAL_ID
GROUP BY
  A.ACTOR_ID, ACTOR_NAME
ORDER BY
  TOTAL_REVENUE DESC;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-9:Show all the actresses who worked in a film having a "Wrestler" in the description?
SELECT DISTINCT
  A.ACTOR_ID,
  CONCAT(A.FIRST_NAME, ' ', A.LAST_NAME) AS ACTOR_NAME
FROM
  ACTOR A
  JOIN FILM_ACTOR FA ON A.ACTOR_ID = FA.ACTOR_ID
  JOIN FILM F ON FA.FILM_ID = F.FILM_ID
WHERE
  F.DESCRIPTION LIKE '%Wrestler%'
ORDER BY
  ACTOR_NAME;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-10:Which customers have rented the same film more than once? 
SELECT c.customer_id, CONCAT_WS(' ', c.first_name, c.last_name) AS Customer_Name,
       i.film_id, f.title AS Movie_Name, COUNT(*) AS Rental_count
FROM customer c
JOIN rental r 
ON c.customer_id = r.customer_id
JOIN inventory i 
ON r.inventory_id = i.inventory_id
JOIN film f 
ON i.film_id = f.film_id
GROUP BY c.customer_id, i.film_id
HAVING COUNT(*) > 1;

----------------------------------------------------------------------------------------------------------------------
#QUESTION-11:How many films in the comedy category have a rental rate higher than the average rental rate?
SELECT COUNT(*) AS NUM_FILMS
FROM FILM F
JOIN FILM_CATEGORY FC ON F.FILM_ID = FC.FILM_ID
JOIN CATEGORY C ON FC.CATEGORY_ID = C.CATEGORY_ID
WHERE C.NAME = 'COMEDY'
AND F.RENTAL_RATE > (SELECT AVG(RENTAL_RATE) FROM FILM);
----------------------------------------------------------------------------------------------------------------------
#QUESTION-12:Which films have been rented the most by customers living in each city?
SELECT
  C.CITY,
  F.TITLE,
  COUNT(*) AS RENTAL_COUNT
FROM
  CITY C
JOIN
  ADDRESS A ON C.CITY_ID = A.CITY_ID
JOIN
  CUSTOMER CU ON A.ADDRESS_ID = CU.ADDRESS_ID
JOIN
  RENTAL R ON CU.CUSTOMER_ID = R.CUSTOMER_ID
JOIN
  INVENTORY I ON R.INVENTORY_ID = I.INVENTORY_ID
JOIN
  FILM F ON I.FILM_ID = F.FILM_ID
WHERE
  R.RETURN_DATE IS NOT NULL
GROUP BY
  C.CITY, F.TITLE
HAVING
  RENTAL_COUNT = (
    SELECT
      MAX(RENTAL_COUNT)
    FROM
      (SELECT
        C.CITY,
        F.TITLE,
        COUNT(*) AS RENTAL_COUNT
      FROM
        CITY C
      JOIN
        ADDRESS A ON C.CITY_ID = A.CITY_ID
      JOIN
        CUSTOMER CU ON A.ADDRESS_ID = CU.ADDRESS_ID
      JOIN
        RENTAL R ON CU.CUSTOMER_ID = R.CUSTOMER_ID
      JOIN
        INVENTORY I ON R.INVENTORY_ID = I.INVENTORY_ID
      JOIN
        FILM F ON I.FILM_ID = F.FILM_ID
      WHERE
        R.RETURN_DATE IS NOT NULL
      GROUP BY
        C.CITY, F.TITLE) AS MAX_RENTALS
    WHERE
      MAX_RENTALS.CITY = C.CITY
  );
----------------------------------------------------------------------------------------------------------------------
#QUESTION-13:What is the total amount spent by customers whose rental payments exceed $200?
SELECT
  CUST.CUSTOMER_ID,
  CUST.FIRST_NAME,
  CUST.LAST_NAME,
  TOTAL_AMOUNT
FROM
  (
    SELECT
      P.CUSTOMER_ID,
      SUM(P.AMOUNT) AS TOTAL_AMOUNT
    FROM
      PAYMENT P
    WHERE
      P.CUSTOMER_ID IN (
        SELECT
          CUSTOMER_ID
        FROM
          PAYMENT
        GROUP BY
          CUSTOMER_ID
        HAVING
          SUM(AMOUNT) > 200
      )
    GROUP BY
      P.CUSTOMER_ID
  ) AS AMOUNT_SUBQ
JOIN
  CUSTOMER CUST ON AMOUNT_SUBQ.CUSTOMER_ID = CUST.CUSTOMER_ID;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-14:Display the fields which are having foreign key constraints related to the "rental" table. [Hint: using Information_schema]
SELECT
    TABLE_NAME,
    COLUMN_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE
    TABLE_SCHEMA = 'film_rental' AND
    REFERENCED_TABLE_NAME = 'rental';
------------------------------------------------------------------------------------------------------------------------------  ----------------------------------------------------------------------------------------------------------------------
#QUESTION-15:Create a View for the total revenue generated by each staff member, broken down by store city with the country name.
CREATE VIEW v_staff_revenue_by_city AS
SELECT
    s.staff_id,
    s.first_name AS staff_first_name,
    s.last_name AS staff_last_name,
    c.city AS store_city,
    co.country AS store_country,
    SUM(p.amount) AS total_revenue
FROM
    staff s
JOIN
    store st ON s.staff_id = st.manager_staff_id
JOIN
    address a ON st.address_id = a.address_id
JOIN
    city c ON a.city_id = c.city_id
JOIN
    country co ON c.country_id = co.country_id
JOIN
    payment p ON s.staff_id = p.staff_id
GROUP BY
    s.staff_id, c.city_id;
select* from v_staff_revenue_by_city;


----------------------------------------------------------------------------------------------------------------------
/*QUESTION-16:Create a view based on rental information consisting of visiting_day, customer_name, 
the title of the film, no_of_rental_days, the amount paid by the customer along with the percentage of 
customer spending.*/
CREATE VIEW rental_info_view AS
SELECT
  r.rental_date AS visiting_day,
  CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
  f.title AS film_title,
  DATEDIFF(r.return_date, r.rental_date) AS no_of_rental_days,
  p.amount AS amount_paid,
  (p.amount / (SELECT SUM(amount) FROM payment WHERE customer_id = c.customer_id) * 100) AS spending_percentage
FROM
  rental r
JOIN
  customer c ON r.customer_id = c.customer_id
JOIN
  inventory i ON r.inventory_id = i.inventory_id
JOIN
  film f ON i.film_id = f.film_id
JOIN
  payment p ON r.rental_id = p.rental_id;
  select * from rental_info_view;
----------------------------------------------------------------------------------------------------------------------
#QUESTION-17:Display the customers who paid 50% of their total rental costs within one day.?
SELECT 
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    r.rental_id,
    SUM(p.amount) AS total_amount_paid,
    DATEDIFF(MAX(r.return_date), MIN(r.rental_date)) AS rental_duration,
    ROUND((SUM(p.amount) / 
           (SELECT SUM(f.rental_rate) 
            FROM film f 
            JOIN inventory i ON f.film_id = i.film_id
            JOIN rental r2 ON i.inventory_id = r2.inventory_id
            WHERE r2.customer_id = r.customer_id AND DATEDIFF(r2.return_date, r2.rental_date) <= 1)
           ) * 100, 2) AS payment_percentage
FROM rental r
JOIN customer c ON r.customer_id = c.customer_id
JOIN payment p ON r.rental_id = p.rental_id
JOIN inventory i ON r.inventory_id = i.inventory_id
JOIN film f ON i.film_id = f.film_id
GROUP BY c.customer_id, r.rental_id
HAVING payment_percentage >= 50 AND rental_duration <= 1;
